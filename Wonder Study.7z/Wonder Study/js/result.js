window.onload = function() {
    console.log("JS is working");
}

var IsDaltonic = false;

function daltClick() {
    if (IsDaltonic == false) {
        IsDaltonic = true;
        console.log("Yes");
        DaltonicsOn();
    } else {
        console.log("No");
        IsDaltonic = false;
        DaltonicsOff();
    }
}

function DaltonicsOn() {
    document.getElementById('eye').src = './img1/closeEye.png';
    document.getElementById('body').style.background = "lightgrey";
    document.getElementById('header').style.background = "grey";
    document.getElementById('footer').style.background = "grey";
    document.getElementById('logo').src = './img1/logoGrey.png';
    document.getElementById('ria').src = './img1/riaGrey.png';
    document.getElementById('epam').src = './img1/epamGrey.png';
    document.getElementById('adobe').src = './img1/adobeGrey.png';
    document.getElementById('itvn').src = './img1/itvnGrey.png';
    document.getElementById('man2').src = './img1/man_2Grey.png';
    document.getElementById('man1').src = './img1/man_1Grey.png';
    document.getElementById('women').src = './img1/womenGrey.png';
}

function DaltonicsOff() {
    document.getElementById('eye').src = './img1/eye.png';
    document.getElementById('body').style.background = "white";
    document.getElementById('header').style.background = "#1F9C95";
    document.getElementById('footer').style.background = "#0A4744";
    document.getElementById('logo').src = './img1/logo.png';
    document.getElementById('ria').src = './img1/ria.png';
    document.getElementById('epam').src = './img1/epam.png';
    document.getElementById('adobe').src = './img1/adobe.png';
    document.getElementById('itvn').src = './img1/itvn.png';
    document.getElementById('man2').src = './img1/man_2.png';
    document.getElementById('man1').src = './img1/man_1.png';
    document.getElementById('women').src = './img1/women.png';
}